<?php

define('URL', 'http://localhost/expense-app/');

define('HOST', 'localhost');
define('DB', 'expense-app');
define('USER', 'root');
define('PASSWORD', "root");
define('CHARSET', 'utf8mb4');

?>
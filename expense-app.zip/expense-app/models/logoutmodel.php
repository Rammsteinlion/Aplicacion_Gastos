<?php

class LogoutModel extends Model{

    public function __construct(){
        parent::__construct();
    }

    

}

?>